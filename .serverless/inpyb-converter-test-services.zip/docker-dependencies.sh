#!/bin/bash

cp parameters.yml chromium-renderer/parameters.yml
cp parameters.yml latex-renderer/parameters.yml
